# docker-dotnet-sample

A simple .NET web application example for [Docker's .NET Language Guide](https://docs.docker.com/language/dotnet/).